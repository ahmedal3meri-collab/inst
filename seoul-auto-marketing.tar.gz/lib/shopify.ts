// lib/shopify.ts
export interface ShopifyProduct {
  id: string;
  title: string;
  handle: string;
  price: string;
  currency: string;
  image: string;
  description: string;
  vendor: string;
  inventory: number;
  status: string;
}

export async function fetchShopifyProducts(): Promise<ShopifyProduct[]> {
  const shopDomain = process.env.SHOPIFY_STORE_DOMAIN;
  const accessToken = process.env.SHOPIFY_ADMIN_TOKEN;

  if (!shopDomain || !accessToken) {
    // Return embedded products if env not set
    return EMBEDDED_PRODUCTS;
  }

  try {
    const query = `
      {
        products(first: 50, query: "status:active") {
          edges {
            node {
              id
              title
              handle
              status
              vendor
              description
              totalInventory
              featuredMedia {
                preview {
                  image {
                    url
                  }
                }
              }
              priceRangeV2 {
                minVariantPrice {
                  amount
                  currencyCode
                }
              }
            }
          }
        }
      }
    `;

    const res = await fetch(
      `https://${shopDomain}/admin/api/2024-01/graphql.json`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Shopify-Access-Token': accessToken,
        },
        body: JSON.stringify({ query }),
      }
    );

    const data = await res.json();
    const products = data?.data?.products?.edges || [];

    return products.map((edge: any) => ({
      id: edge.node.id.split('/').pop(),
      title: edge.node.title,
      handle: edge.node.handle,
      price: parseFloat(edge.node.priceRangeV2.minVariantPrice.amount).toFixed(0),
      currency: edge.node.priceRangeV2.minVariantPrice.currencyCode,
      image: edge.node.featuredMedia?.preview?.image?.url || '',
      description: edge.node.description?.slice(0, 200) || '',
      vendor: edge.node.vendor,
      inventory: edge.node.totalInventory || 0,
      status: edge.node.status,
    }));
  } catch (err) {
    console.error('Shopify fetch error:', err);
    return EMBEDDED_PRODUCTS;
  }
}

// All 35 products embedded as fallback
export const EMBEDDED_PRODUCTS: ShopifyProduct[] = [
  { id: '8278407348294', title: 'Some By Mi Retinol Intense Reactivating Serum 30ml', handle: 'some-by-mi-retinol-intense-reactivating-serum-30ml', price: '54', currency: 'AED', image: 'https://cdn.shopify.com/s/files/1/0717/7378/2086/files/some-by-mi-retinol-intense-reactivating-serum-30ml-519-260.jpg?v=1773441915', description: 'Retinol serum for skin reactivation and anti-aging with niacinamide', vendor: 'K-uae', inventory: 0, status: 'ACTIVE' },
  { id: '8278407381062', title: 'DARK SPOT CREAM', handle: 'dark-spot-cream', price: '55', currency: 'AED', image: 'https://cdn.shopify.com/s/files/1/0717/7378/2086/files/dark-spot-cream-463-782.png?v=1775021481', description: 'Dark spot correcting cream for brightening and hyperpigmentation', vendor: 'K-uae', inventory: 2, status: 'ACTIVE' },
  { id: '8278407675974', title: 'Triple Action Eye Cream Original', handle: 'triple-action-eye-cream-original', price: '50', currency: 'AED', image: 'https://cdn.shopify.com/s/files/1/0717/7378/2086/files/triple-action-eye-cream-original-272-706.png?v=1775021080', description: 'Eye cream for dark circles, puffiness, and fine lines', vendor: 'K-uae', inventory: 0, status: 'ACTIVE' },
  { id: '8278407938118', title: 'Ordinary Euk 134 * 0.10ml (Original)', handle: 'ordinary-euk-134-0-10ml-original', price: '54', currency: 'AED', image: 'https://cdn.shopify.com/s/files/1/0717/7378/2086/files/C8E8DE0C-569D-4485-8E6D-A8D9C21FFB36.png?v=1775019714', description: 'Powerful antioxidant EUK 134 for protection against free radicals', vendor: 'K-uae', inventory: 0, status: 'ACTIVE' },
  { id: '8278408036422', title: 'Ordinary Buffet Serum (Original)', handle: 'ordinary-buffet-serum-original', price: '54', currency: 'AED', image: 'https://cdn.shopify.com/s/files/1/0717/7378/2086/files/ordinary-buffet-serum-original-262-368.png?v=1775019585', description: 'Multi-peptide serum targeting multiple signs of aging', vendor: 'K-uae', inventory: 0, status: 'ACTIVE' },
  { id: '8278408233030', title: 'Lactic Acid 10% + HA (Original)', handle: 'lactic-acid-10-ha-original', price: '52', currency: 'AED', image: 'https://cdn.shopify.com/s/files/1/0717/7378/2086/files/27833A10-5229-4BA1-83A4-DE5D79D1FEEE.jpg?v=1773500632', description: 'Lactic acid exfoliator with hyaluronic acid for bright smooth skin', vendor: 'SeoulGlowUAE', inventory: 0, status: 'ACTIVE' },
  { id: '8298161176646', title: 'Medicube Red Acne Body Peeling Shot 2.0', handle: 'medicube-red-acne-body-peeling-shot-2-0-110gm-exfoliating-spray', price: '90', currency: 'AED', image: 'https://cdn.shopify.com/s/files/1/0717/7378/2086/files/IMG-0155.webp?v=1773582567', description: 'Exfoliating body spray for acne and pore cleansing', vendor: 'SeoulGlowUAE', inventory: 3, status: 'ACTIVE' },
  { id: '8298161504326', title: 'Medicube Kojic Acid Turmeric Toning Cleanser', handle: 'medicube-kojic-acid-tumeric-toning-cleanser-120g', price: '65', currency: 'AED', image: 'https://cdn.shopify.com/s/files/1/0717/7378/2086/files/IMG-0157.jpg?v=1773582754', description: 'Daily brightening cleanser with kojic acid and turmeric', vendor: 'SeoulGlowUAE', inventory: 4, status: 'ACTIVE' },
  { id: '8298161569862', title: 'Medicube Red Succinic Acid Peeling Pad', handle: 'medicube-red-succinic-acid-peeling-pads-155g-70-pads', price: '80', currency: 'AED', image: 'https://cdn.shopify.com/s/files/1/0717/7378/2086/files/764E68D3-3FFC-481A-8DA5-17B78EA08A17.webp?v=1773582965', description: 'Peeling pads for deep pore cleansing and acne reduction', vendor: 'SeoulGlowUAE', inventory: 2, status: 'ACTIVE' },
  { id: '8298161995846', title: 'Medicube Kojic Acid Turmeric Pad', handle: 'medicube-medicube-kojic-acid-turmeric-pad-70pcs', price: '80', currency: 'AED', image: 'https://cdn.shopify.com/s/files/1/0717/7378/2086/files/IMG-0160.png?v=1775020536', description: 'Brightening pads with kojic acid and turmeric for even skin tone', vendor: 'SeoulGlowUAE', inventory: 4, status: 'ACTIVE' },
  { id: '8298162094150', title: 'Medicube TXA Niacinamide 15 Serum', handle: 'txa-niacinamide-15-glow-facial-serum-30ml', price: '75', currency: 'AED', image: 'https://cdn.shopify.com/s/files/1/0717/7378/2086/files/B1913B8E-0AA1-4A6A-9794-B72F46C70B40.png?v=1775020488', description: 'Brightening serum with TXA and Niacinamide for even skin tone', vendor: 'SeoulGlowUAE', inventory: 3, status: 'ACTIVE' },
  { id: '8300244959302', title: 'SKIN1004 Madagascar Centella Poremizing Light Gel Cream', handle: 'skin1004-madagascar-centella-poremizing-light-gel-cream', price: '65', currency: 'AED', image: 'https://cdn.shopify.com/s/files/1/0717/7378/2086/files/69AC0B43-F9A1-4080-9CC6-3ED40A471F2A.png?v=1775020402', description: 'Light gel cream for pore minimizing and oil control', vendor: 'SeoulGlowUAE', inventory: 3, status: 'ACTIVE' },
  { id: '8300252561478', title: 'SKIN1004 Madagascar Centella Probio-Cica Intensive Ampoule', handle: 'skin1004-madagascar-centella-probio-cica-intensive-ampoule-50ml', price: '72', currency: 'AED', image: 'https://cdn.shopify.com/s/files/1/0717/7378/2086/files/IMG-0192.jpg?v=1773745466', description: 'Intensive ampoule for sensitive skin soothing and barrier repair', vendor: 'SeoulGlowUAE', inventory: 3, status: 'ACTIVE' },
  { id: '8300258951238', title: 'SKIN1004 Tone Brightening Cleansing Gel Foam', handle: 'skin1004-tone-brightening-cleansing-gel-foam', price: '55', currency: 'AED', image: 'https://cdn.shopify.com/s/files/1/0717/7378/2086/files/IMG-0193.png?v=1775019865', description: 'Gentle brightening cleanser for deep cleansing and even skin tone', vendor: 'SeoulGlowUAE', inventory: 3, status: 'ACTIVE' },
  { id: '8300259409990', title: 'SKIN1004 Madagascar Centella Cream', handle: 'skin1004-madagascar-centella-cream', price: '80', currency: 'AED', image: 'https://cdn.shopify.com/s/files/1/0717/7378/2086/files/IMG-0194_18819464-cbc1-4964-8cf4-f400772e796e.png?v=1775020177', description: 'Soothing centella cream for redness relief and deep hydration', vendor: 'SeoulGlowUAE', inventory: 3, status: 'ACTIVE' },
  { id: '8300262522950', title: 'Skin1004 Madagascar Centella Cream 75ml', handle: 'skin1004-madagascar-centella-cream-75ml', price: '80', currency: 'AED', image: 'https://cdn.shopify.com/s/files/1/0717/7378/2086/files/IMG-0195.png?v=1775020292', description: 'Madagascar centella cream for balanced hydrated skin', vendor: 'SeoulGlowUAE', inventory: 3, status: 'ACTIVE' },
  { id: '8300266815558', title: 'SKIN1004 Tone Brightening Boosting Toner', handle: 'skin1004-tone-brightening-boosting-toner', price: '64', currency: 'AED', image: 'https://cdn.shopify.com/s/files/1/0717/7378/2086/files/IMG-0196.png?v=1775020052', description: 'Brightening toner for skin tone unification and deep hydration', vendor: 'SeoulGlowUAE', inventory: 3, status: 'ACTIVE' },
  { id: '8300361547846', title: 'Purito Mighty Bamboo Panthenol Cream', handle: 'purito-mighty-bamboo-panthenol-cream-100ml', price: '70', currency: 'AED', image: 'https://cdn.shopify.com/s/files/1/0717/7378/2086/files/IMG-0217.webp?v=1773753189', description: 'Rich moisturizing cream with panthenol and bamboo extract', vendor: 'SeoulGlowUAE', inventory: 3, status: 'ACTIVE' },
  { id: '8304798367814', title: 'numbuzin No.3 Pore Reset Ampoule', handle: 'numbuzin-no-3-pore-reset-ampoule-korean-skin-solution', price: '90', currency: 'AED', image: 'https://cdn.shopify.com/s/files/1/0717/7378/2086/files/IMG-0272.png?v=1774138605', description: 'Concentrated ampoule for pore minimizing and skin texture improvement', vendor: 'SeoulGlowUAE', inventory: 3, status: 'ACTIVE' },
  { id: '8304798629958', title: 'numbuzin No.9 Eye Cream', handle: 'numbuzin-no-9-eye-cream', price: '70', currency: 'AED', image: 'https://cdn.shopify.com/s/files/1/0717/7378/2086/files/IMG-0276.png?v=1774139164', description: 'Advanced eye cream for dark circles and fine lines', vendor: 'SeoulGlowUAE', inventory: 3, status: 'ACTIVE' },
  { id: '8304799940678', title: 'PDRN Cream – Skin Repair & Glow Effect', handle: 'dr-althea-pdrn-rej5000-cream', price: '85', currency: 'AED', image: 'https://cdn.shopify.com/s/files/1/0717/7378/2086/files/IMG-0275.png?v=1774139387', description: 'Advanced PDRN cream for skin renewal and deep hydration', vendor: 'SeoulGlowUAE', inventory: 3, status: 'ACTIVE' },
  { id: '8304807280710', title: 'Dr. Althea 345 Relief Cream Mist', handle: 'dr-althea-345-relief-cream-mist', price: '60', currency: 'AED', image: 'https://cdn.shopify.com/s/files/1/0717/7378/2086/files/IMG-0279.jpg?v=1774144861', description: 'Cream mist for instant hydration and redness relief', vendor: 'SeoulGlowUAE', inventory: 4, status: 'ACTIVE' },
  { id: '8304807706694', title: 'Dr. Althea Aqua Mist – Instant Hydration Boost', handle: 'dr-althea-aqua-marine-jelly-mist', price: '80', currency: 'AED', image: 'https://cdn.shopify.com/s/files/1/0717/7378/2086/files/IMG-0280.webp?v=1774145469', description: 'Hydrating jelly mist for instant freshness and natural glow', vendor: 'SeoulGlowUAE', inventory: 2, status: 'ACTIVE' },
  { id: '8304808263750', title: 'Numbuzin Glutathione Serum – Glow & Brightening Effect', handle: 'numbuzin-no-5-glutathione-serum', price: '85', currency: 'AED', image: 'https://cdn.shopify.com/s/files/1/0717/7378/2086/files/IMG-0283.webp?v=1775019119', description: 'Concentrated glutathione serum for brightening and dark spot reduction', vendor: 'SeoulGlowUAE', inventory: 6, status: 'ACTIVE' },
  { id: '8304808394822', title: 'Numbuzin Pads – Gentle Exfoliation & Glow', handle: 'numbuzin-no-5-toner-pads', price: '82', currency: 'AED', image: 'https://cdn.shopify.com/s/files/1/0717/7378/2086/files/IMG-0282.png?v=1775019301', description: 'Toner pads with glutathione and vitamin C for brightening', vendor: 'SeoulGlowUAE', inventory: 2, status: 'ACTIVE' },
  { id: '8315897905222', title: 'Eqqualberry Peptide Serum – Firm & Youthful Skin', handle: 'eqqualberry-nad-peptide-boosting-serum', price: '90', currency: 'AED', image: 'https://cdn.shopify.com/s/files/1/0717/7378/2086/files/IMG-0435.webp?v=1774817199', description: 'NAD+ peptide serum for skin firmness and anti-aging', vendor: 'SeoulGlowUAE', inventory: 6, status: 'ACTIVE' },
  { id: '8315900035142', title: 'Bakuchiol Serum – Anti-Aging & Smooth Skin', handle: 'eqqualberry-bakuchiol-plumping-serum-30ml', price: '90', currency: 'AED', image: 'https://cdn.shopify.com/s/files/1/0717/7378/2086/files/IMG-0437.webp?v=1775019445', description: 'Bakuchiol serum for plumping and anti-aging without irritation', vendor: 'SeoulGlowUAE', inventory: 3, status: 'ACTIVE' },
  { id: '8315900657734', title: 'Anua Heartleaf Cleanser – Calm & Clear Skin', handle: 'anua-heartleaf-quercetinol-pore-deep-cleansing-foam-150-ml', price: '70', currency: 'AED', image: 'https://cdn.shopify.com/s/files/1/0717/7378/2086/files/IMG-0438.jpg?v=1774817550', description: 'Deep pore cleanser with heartleaf and BHA for clear skin', vendor: 'SeoulGlowUAE', inventory: 1, status: 'ACTIVE' },
  { id: '8315900985414', title: 'Beauty of Joseon Relief Sun – Protect & Glow Skin', handle: 'beauty-of-joseon-relief-sun-rice-probiotics-spf-50-50ml', price: '60', currency: 'AED', image: 'https://cdn.shopify.com/s/files/1/0717/7378/2086/files/IMG-0439.webp?v=1774817724', description: 'SPF50 sunscreen with rice and probiotics for glowing protection', vendor: 'SeoulGlowUAE', inventory: 6, status: 'ACTIVE' },
  { id: '8315901837382', title: 'Medicube Zero Pore Pads – Smooth & Tight Skin', handle: 'medicube-zero-pore-pads-2-0-70pcs', price: '80', currency: 'AED', image: 'https://cdn.shopify.com/s/files/1/0717/7378/2086/files/5C8493ED-F026-40D9-B1BA-29B63F42039D.png?v=1775019055', description: 'Daily exfoliating pads for pore cleansing and smooth skin', vendor: 'SeoulGlowUAE', inventory: 3, status: 'ACTIVE' },
  { id: '8315935162438', title: 'ترطيب وتنظيف المسام ✨', handle: 'bundle-hydration-pore', price: '160', currency: 'AED', image: 'https://cdn.shopify.com/s/files/1/0717/7378/2086/files/1DDCF69B-3EE4-4995-8584-03B58CB4DB20.png?v=1774927411', description: 'Bundle: Dr Althea Aqua Mist + Medicube Zero Pore Pad', vendor: 'SeoulGlowUAE', inventory: 2, status: 'ACTIVE' },
  { id: '8315935785030', title: 'Acne Control Treatment – Clear Skin Solution', handle: 'acne-control-power', price: '160', currency: 'AED', image: 'https://cdn.shopify.com/s/files/1/0717/7378/2086/files/ABCA3655-D89D-4464-82C7-82060DB954D5.png?v=1774825991', description: 'Bundle: Succinic Acid Peeling Pad + Body Peeling Shot for acne', vendor: 'SeoulGlowUAE', inventory: 2, status: 'ACTIVE' },
  { id: '8315936505926', title: 'Glass Skin Glow ✨', handle: 'glass-skin-glow', price: '180', currency: 'AED', image: 'https://cdn.shopify.com/s/files/1/0717/7378/2086/files/459834E0-A609-4218-9C31-9323694667AD.png?v=1774825991', description: 'Bundle: Eqqualberry Peptide Serum + Bakuchiol Serum', vendor: 'SeoulGlowUAE', inventory: 4, status: 'ACTIVE' },
  { id: '8315937226822', title: 'Repair & Lift Cream – Firm & Tight Skin', handle: 'repair-lift', price: '169', currency: 'AED', image: 'https://cdn.shopify.com/s/files/1/0717/7378/2086/files/AAC2F631-A85E-4641-9A19-1973D1323AE6.png?v=1774825991', description: 'Bundle: Eqqualberry Peptide Serum + PDRN Cream', vendor: 'SeoulGlowUAE', inventory: 1, status: 'ACTIVE' },
  { id: '8317557014598', title: 'The Ordinary Glycolic Acid – Smooth & Clear Skin', handle: 'the-ordinary-glycolic-acid-7-exfoliating-toner', price: '79', currency: 'AED', image: 'https://cdn.shopify.com/s/files/1/0717/7378/2086/files/IMG-0496.webp?v=1775018680', description: '7% glycolic acid toner for skin exfoliation and brightness', vendor: 'SeoulGlowUAE', inventory: 4, status: 'ACTIVE' },
  { id: '8317557473350', title: 'Dr. Althea Relief Cream – Deep Hydration & Repair', handle: 'dr-althea-345-relief-cream-50ml-post-acne-soothing-care', price: '60', currency: 'AED', image: 'https://cdn.shopify.com/s/files/1/0717/7378/2086/files/IMG-0497.png?v=1775021684', description: 'Soothing cream for post-acne skin with deep repair', vendor: 'SeoulGlowUAE', inventory: 4, status: 'ACTIVE' },
  { id: '8319229755462', title: 'Age-R Pink Glow Set', handle: 'age-r-pink-glow-set', price: '500', currency: 'AED', image: 'https://cdn.shopify.com/s/files/1/0717/7378/2086/files/IMG-0577.png?v=1775003590', description: 'Complete glow set with Medicube Age-R PRO Booster device', vendor: 'SeoulGlowUAE', inventory: 1, status: 'ACTIVE' },
];
