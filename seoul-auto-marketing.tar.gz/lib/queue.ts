// lib/queue.ts - In-memory queue with persistence via global state
export interface QueuedPost {
  id: string;
  productId: string;
  productTitle: string;
  productImage: string;
  productPrice: string;
  platform: 'instagram' | 'tiktok' | 'both';
  contentType: 'post' | 'story' | 'reel';
  tone: string;
  caption: string;
  hashtags: string[];
  hook: string;
  cta: string;
  bestTime: string;
  visualTip: string;
  scheduledFor: string; // ISO string
  status: 'pending' | 'sent' | 'failed' | 'paused';
  createdAt: string;
  sentAt?: string;
  error?: string;
  zapierWebhookUrl: string;
  autoMode: boolean;
}

export interface AutoPilotSettings {
  enabled: boolean;
  postsPerDay: number;
  platforms: ('instagram' | 'tiktok')[];
  preferredTimes: string[]; // e.g. ['09:00', '13:00', '20:00']
  tones: string[];
  contentTypes: string[];
  zapierWebhookUrl: string;
  rotateProducts: boolean;
  lastProductIndex: number;
}

// Global in-memory store (survives between API calls in same serverless instance)
declare global {
  var __queue: QueuedPost[];
  var __autopilot: AutoPilotSettings;
  var __stats: { totalSent: number; totalFailed: number; lastRun: string };
}

if (!global.__queue) {
  global.__queue = [];
}

if (!global.__autopilot) {
  global.__autopilot = {
    enabled: false,
    postsPerDay: 2,
    platforms: ['instagram'],
    preferredTimes: ['09:00', '20:00'],
    tones: ['luxury', 'educational'],
    contentTypes: ['post', 'story'],
    zapierWebhookUrl: '',
    rotateProducts: true,
    lastProductIndex: 0,
  };
}

if (!global.__stats) {
  global.__stats = { totalSent: 0, totalFailed: 0, lastRun: '' };
}

export function getQueue(): QueuedPost[] {
  return global.__queue;
}

export function addToQueue(post: Omit<QueuedPost, 'id' | 'createdAt'>): QueuedPost {
  const newPost: QueuedPost = {
    ...post,
    id: `post_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    createdAt: new Date().toISOString(),
  };
  global.__queue.unshift(newPost);
  return newPost;
}

export function updateQueueItem(id: string, updates: Partial<QueuedPost>): void {
  const idx = global.__queue.findIndex(p => p.id === id);
  if (idx !== -1) {
    global.__queue[idx] = { ...global.__queue[idx], ...updates };
  }
}

export function removeFromQueue(id: string): void {
  global.__queue = global.__queue.filter(p => p.id !== id);
}

export function getAutoPilot(): AutoPilotSettings {
  return global.__autopilot;
}

export function setAutoPilot(settings: Partial<AutoPilotSettings>): void {
  global.__autopilot = { ...global.__autopilot, ...settings };
}

export function getStats() {
  return global.__stats;
}

export function incrementStats(success: boolean) {
  if (success) global.__stats.totalSent++;
  else global.__stats.totalFailed++;
  global.__stats.lastRun = new Date().toISOString();
}
