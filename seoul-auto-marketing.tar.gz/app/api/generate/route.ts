// app/api/generate/route.ts
import { NextRequest, NextResponse } from 'next/server';
import Anthropic from '@anthropic-ai/sdk';

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

export async function POST(req: NextRequest) {
  try {
    const { product, platform, contentType, tone } = await req.json();

    const platformLabel = platform === 'instagram' ? 'Instagram' : platform === 'tiktok' ? 'TikTok' : 'Instagram و TikTok';
    const typeLabel = contentType === 'post' ? 'بوست' : contentType === 'story' ? 'ستوري' : 'ريل / فيديو قصير';
    const toneMap: Record<string, string> = {
      luxury: 'فخم وراقي يستهدف العميل الخليجي المهتم بالجمال الكوري',
      funny: 'خفيف ومرح وفيه طاقة إيجابية تجذب الشباب',
      educational: 'تثقيفي يشرح فوائد المكونات بأسلوب واضح',
      urgent: 'عرض محدود وإلحاح لتحفيز الشراء الفوري',
    };
    const toneDesc = toneMap[tone] || toneMap.luxury;

    const prompt = `أنت خبير تسويق رقمي متخصص بشكل حصري في العناية بالبشرة الكورية للسوق الإماراتي والخليجي.
قاعدة عملائك: نساء وشباب خليجيون من 18-35 سنة يحبون الجمال الكوري.

المنتج: ${product.title}
السعر: ${product.price} ${product.currency}
وصف المنتج: ${product.description}
المنصة: ${platformLabel}
نوع المحتوى: ${typeLabel}
الأسلوب: ${toneDesc}

اكتب محتوى تسويقي احترافي باللهجة الخليجية (مزيج عربي خفيف) مناسب لـ${platformLabel}.

أعطني JSON فقط بدون أي نص خارجي أو backticks:
{
  "hook": "جملة واحدة قوية تجذب الانتباه في أول ثانيتين",
  "mainText": "3-4 أسطر تسويقية مقنعة",
  "cta": "جملة نهائية تحث على الشراء مع رابط أو طلب",
  "hashtags": ["هاشتاق1", "هاشتاق2", ...15 هاشتاق مزيج عربي وإنجليزي],
  "bestTime": "أفضل وقت ويوم للنشر",
  "visualTip": "نصيحة محددة للصورة أو الفيديو",
  "fullCaption": "النص الكامل الجاهز للنسخ مع الهاشتاقات"
}`;

    const response = await client.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1200,
      messages: [{ role: 'user', content: prompt }],
    });

    const text = response.content[0].type === 'text' ? response.content[0].text : '';
    const clean = text.replace(/```json|```/g, '').trim();
    const parsed = JSON.parse(clean);

    return NextResponse.json({ success: true, content: parsed });
  } catch (err: any) {
    console.error('Generate error:', err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
