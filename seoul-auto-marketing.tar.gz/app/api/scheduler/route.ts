// app/api/scheduler/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getAutoPilot, setAutoPilot, getQueue, addToQueue, updateQueueItem, incrementStats } from '@/lib/queue';
import { fetchShopifyProducts, EMBEDDED_PRODUCTS } from '@/lib/shopify';
import Anthropic from '@anthropic-ai/sdk';

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

// GET: return autopilot settings
export async function GET() {
  const settings = getAutoPilot();
  const queue = getQueue();
  return NextResponse.json({ settings, queueLength: queue.length });
}

// POST: update settings
export async function POST(req: NextRequest) {
  const body = await req.json();
  setAutoPilot(body);
  return NextResponse.json({ success: true, settings: getAutoPilot() });
}

// PUT: trigger autopilot run (called by Vercel Cron)
export async function PUT(req: NextRequest) {
  // Verify cron secret
  const authHeader = req.headers.get('authorization');
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const settings = getAutoPilot();
  if (!settings.enabled) {
    return NextResponse.json({ message: 'Autopilot is disabled' });
  }
  if (!settings.zapierWebhookUrl) {
    return NextResponse.json({ error: 'No Zapier webhook URL configured' });
  }

  try {
    // Get products
    let products = EMBEDDED_PRODUCTS;
    try {
      products = await fetchShopifyProducts();
    } catch {}

    const results = [];

    // Process due posts in queue
    const queue = getQueue();
    const now = new Date();
    const duePosts = queue.filter(
      p => p.status === 'pending' && new Date(p.scheduledFor) <= now
    );

    for (const post of duePosts) {
      try {
        const payload = {
          product_title: post.productTitle,
          product_image_url: post.productImage,
          product_price: post.productPrice,
          caption: post.caption,
          hook: post.hook,
          cta: post.cta,
          hashtags: post.hashtags?.join(' '),
          full_caption: `${post.hook}\n\n${post.caption}\n\n${post.cta}\n\n${post.hashtags?.join(' ')}`,
          platform: post.platform,
          content_type: post.contentType,
          scheduled_for: post.scheduledFor,
          publish_now: true,
          post_id: post.id,
          sent_at: now.toISOString(),
          store: 'SeoulGlowUAE',
          auto_generated: true,
        };

        const res = await fetch(settings.zapierWebhookUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });

        if (res.ok) {
          updateQueueItem(post.id, { status: 'sent', sentAt: now.toISOString() });
          incrementStats(true);
          results.push({ id: post.id, status: 'sent' });
        } else {
          updateQueueItem(post.id, { status: 'failed', error: `HTTP ${res.status}` });
          incrementStats(false);
          results.push({ id: post.id, status: 'failed' });
        }
      } catch (err: any) {
        updateQueueItem(post.id, { status: 'failed', error: err.message });
        incrementStats(false);
        results.push({ id: post.id, status: 'failed', error: err.message });
      }
    }

    // Auto-generate new posts if autopilot is enabled
    if (settings.enabled && settings.rotateProducts) {
      const pendingCount = queue.filter(p => p.status === 'pending').length;
      if (pendingCount < settings.postsPerDay * 2) {
        // Generate content for next product in rotation
        const product = products[settings.lastProductIndex % products.length];
        const platform = settings.platforms[0] || 'instagram';
        const tone = settings.tones[Math.floor(Math.random() * settings.tones.length)] || 'luxury';
        const contentType = settings.contentTypes[Math.floor(Math.random() * settings.contentTypes.length)] || 'post';

        const toneMap: Record<string, string> = {
          luxury: 'فخم وراقي يستهدف العميل الخليجي',
          funny: 'خفيف ومرح يجذب الشباب',
          educational: 'تثقيفي يشرح فوائد المكونات',
          urgent: 'عرض محدود وإلحاح لتحفيز الشراء الفوري',
        };

        const aiRes = await client.messages.create({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 1000,
          messages: [{
            role: 'user',
            content: `أنت خبير تسويق كوري للسوق الخليجي. اكتب محتوى لـ${platform} عن هذا المنتج:
المنتج: ${product.title}
السعر: ${product.price} ${product.currency}
الوصف: ${product.description}
الأسلوب: ${toneMap[tone]}

JSON فقط:
{"hook":"...","mainText":"...","cta":"...","hashtags":["..."],"bestTime":"...","visualTip":"...","fullCaption":"..."}`
          }]
        });

        const aiText = aiRes.content[0].type === 'text' ? aiRes.content[0].text : '';
        const aiContent = JSON.parse(aiText.replace(/```json|```/g, '').trim());

        // Schedule for next preferred time
        const nextTime = getNextScheduledTime(settings.preferredTimes);

        addToQueue({
          productId: product.id,
          productTitle: product.title,
          productImage: product.image,
          productPrice: `${product.price} ${product.currency}`,
          platform: platform as any,
          contentType: contentType as any,
          tone,
          caption: aiContent.mainText,
          hashtags: aiContent.hashtags,
          hook: aiContent.hook,
          cta: aiContent.cta,
          bestTime: aiContent.bestTime,
          visualTip: aiContent.visualTip,
          scheduledFor: nextTime,
          status: 'pending',
          zapierWebhookUrl: settings.zapierWebhookUrl,
          autoMode: true,
        });

        setAutoPilot({ lastProductIndex: (settings.lastProductIndex + 1) % products.length });
        results.push({ action: 'generated_new_post', product: product.title });
      }
    }

    return NextResponse.json({ success: true, processed: results.length, results });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

function getNextScheduledTime(preferredTimes: string[]): string {
  const now = new Date();
  const today = now.toISOString().split('T')[0];

  for (const time of preferredTimes) {
    const [h, m] = time.split(':').map(Number);
    const candidate = new Date(`${today}T${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:00`);
    if (candidate > now) return candidate.toISOString();
  }

  // Tomorrow first slot
  const tomorrow = new Date(now);
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowStr = tomorrow.toISOString().split('T')[0];
  const [h, m] = preferredTimes[0]?.split(':').map(Number) || [9, 0];
  return new Date(`${tomorrowStr}T${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:00`).toISOString();
}
