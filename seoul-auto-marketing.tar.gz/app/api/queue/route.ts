// app/api/queue/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getQueue, addToQueue, updateQueueItem, removeFromQueue, getStats } from '@/lib/queue';

export async function GET() {
  const queue = getQueue();
  const stats = getStats();
  return NextResponse.json({ queue, stats });
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const post = addToQueue(body);
  return NextResponse.json({ success: true, post });
}

export async function PATCH(req: NextRequest) {
  const { id, ...updates } = await req.json();
  updateQueueItem(id, updates);
  return NextResponse.json({ success: true });
}

export async function DELETE(req: NextRequest) {
  const { id } = await req.json();
  removeFromQueue(id);
  return NextResponse.json({ success: true });
}
