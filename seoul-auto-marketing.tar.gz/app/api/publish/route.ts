// app/api/publish/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { updateQueueItem, incrementStats } from '@/lib/queue';

export async function POST(req: NextRequest) {
  try {
    const { postId, post, webhookUrl } = await req.json();

    if (!webhookUrl) {
      return NextResponse.json({ error: 'Zapier webhook URL required' }, { status: 400 });
    }

    // Build Zapier payload
    const payload = {
      // Product info
      product_id: post.productId,
      product_title: post.productTitle,
      product_price: post.productPrice,
      product_image_url: post.productImage,
      
      // Content
      caption: post.caption,
      hook: post.hook,
      cta: post.cta,
      hashtags: post.hashtags?.join(' '),
      full_caption: `${post.hook}\n\n${post.caption}\n\n${post.cta}\n\n${post.hashtags?.join(' ')}`,
      
      // Settings
      platform: post.platform,
      content_type: post.contentType,
      tone: post.tone,
      
      // Scheduling
      scheduled_for: post.scheduledFor,
      publish_now: new Date(post.scheduledFor) <= new Date(),
      
      // Meta
      post_id: postId,
      sent_at: new Date().toISOString(),
      store: 'SeoulGlowUAE',
    };

    // Send to Zapier
    const zapRes = await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    if (!zapRes.ok) {
      const errText = await zapRes.text();
      throw new Error(`Zapier error ${zapRes.status}: ${errText}`);
    }

    // Update queue status
    if (postId) {
      updateQueueItem(postId, {
        status: 'sent',
        sentAt: new Date().toISOString(),
      });
    }
    incrementStats(true);

    return NextResponse.json({ success: true, message: 'Sent to Zapier successfully' });
  } catch (err: any) {
    if (req.body) {
      try {
        const { postId } = await req.json().catch(() => ({}));
        if (postId) updateQueueItem(postId, { status: 'failed', error: err.message });
      } catch {}
    }
    incrementStats(false);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
