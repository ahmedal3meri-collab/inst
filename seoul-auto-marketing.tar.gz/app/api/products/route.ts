// app/api/products/route.ts
import { NextResponse } from 'next/server';
import { fetchShopifyProducts } from '@/lib/shopify';

export async function GET() {
  try {
    const products = await fetchShopifyProducts();
    return NextResponse.json({ products, count: products.length, updatedAt: new Date().toISOString() });
  } catch (err) {
    return NextResponse.json({ error: 'Failed to fetch products' }, { status: 500 });
  }
}
