// app/layout.tsx
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'SeoulGlow – Auto Marketing Engine',
  description: 'نظام التسويق الأوتوماتيكي لمنتجات العناية بالبشرة',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;800;900&display=swap" rel="stylesheet" />
      </head>
      <body style={{ margin: 0, padding: 0, fontFamily: "'Tajawal', sans-serif", background: '#060610' }}>
        {children}
      </body>
    </html>
  )
}
