'use client';
import { useState, useEffect, useCallback, useRef } from 'react';

// ─── Types ───────────────────────────────────────────────────────
interface Product { id: string; title: string; price: string; currency: string; image: string; description: string; vendor: string; inventory: number; }
interface GeneratedContent { hook: string; mainText: string; cta: string; hashtags: string[]; bestTime: string; visualTip: string; fullCaption: string; }
interface QueuedPost { id: string; productTitle: string; productImage: string; productPrice: string; platform: string; contentType: string; status: string; scheduledFor: string; caption: string; hook: string; autoMode: boolean; }
interface AutoPilotSettings { enabled: boolean; postsPerDay: number; platforms: string[]; preferredTimes: string[]; tones: string[]; contentTypes: string[]; zapierWebhookUrl: string; rotateProducts: boolean; }
interface Stats { totalSent: number; totalFailed: number; lastRun: string; }

const PLATFORM_OPTIONS = [{ id: 'instagram', label: 'Instagram', icon: '📸', color: '#E1306C' }, { id: 'tiktok', label: 'TikTok', icon: '🎵', color: '#69C9D0' }, { id: 'both', label: 'كلاهما', icon: '🚀', color: '#a78bfa' }];
const TYPE_OPTIONS = [{ id: 'post', label: 'بوست' }, { id: 'story', label: 'ستوري' }, { id: 'reel', label: 'ريل' }];
const TONE_OPTIONS = [{ id: 'luxury', label: '✨ فخم' }, { id: 'educational', label: '📚 تثقيفي' }, { id: 'funny', label: '😄 مرح' }, { id: 'urgent', label: '🔥 عرض محدود' }];

// ─── CSS ─────────────────────────────────────────────────────────
const css = `
*{box-sizing:border-box;margin:0;padding:0}
:root{--bg:#060610;--bg2:#0d0d1f;--bg3:#141428;--border:rgba(255,255,255,0.07);--purple:#7c3aed;--pink:#e1306c;--cyan:#22d3ee;--green:#10b981;--gold:#f59e0b;--text:#f1f1f1;--muted:#6b7280}
body{background:var(--bg);color:var(--text);font-family:'Tajawal',sans-serif;direction:rtl;min-height:100vh;overflow-x:hidden}
::-webkit-scrollbar{width:4px}::-webkit-scrollbar-track{background:var(--bg)}::-webkit-scrollbar-thumb{background:var(--purple);border-radius:2px}
.app{display:grid;grid-template-columns:260px 1fr;min-height:100vh}
.sidebar{background:var(--bg2);border-left:1px solid var(--border);display:flex;flex-direction:column;overflow-y:auto;position:sticky;top:0;height:100vh}
.sidebar-logo{padding:24px 20px 16px;border-bottom:1px solid var(--border)}
.logo-text{font-size:20px;font-weight:900;background:linear-gradient(135deg,#a78bfa,var(--pink));-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.logo-sub{font-size:11px;color:var(--muted);margin-top:4px}
.nav-section{padding:16px 12px 8px}
.nav-label{font-size:10px;color:var(--muted);letter-spacing:1px;padding:0 8px;margin-bottom:6px;text-transform:uppercase}
.nav-btn{width:100%;display:flex;align-items:center;gap:10px;padding:10px 12px;border:none;background:transparent;color:var(--muted);cursor:pointer;border-radius:10px;font-family:'Tajawal',sans-serif;font-size:14px;transition:all .2s;text-align:right}
.nav-btn:hover{background:rgba(124,58,237,0.1);color:var(--text)}
.nav-btn.active{background:rgba(124,58,237,0.15);color:#a78bfa;font-weight:600}
.nav-icon{font-size:18px;width:24px;text-align:center}
.status-dot{width:7px;height:7px;border-radius:50%;margin-right:auto}
.status-on{background:var(--green);box-shadow:0 0 6px var(--green)}
.status-off{background:var(--muted)}
.main{overflow-y:auto;min-height:100vh}
.topbar{padding:20px 32px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;background:rgba(6,6,16,0.9);backdrop-filter:blur(12px);z-index:10}
.topbar-title{font-size:22px;font-weight:800}
.topbar-badges{display:flex;gap:8px}
.badge{padding:5px 14px;border-radius:50px;font-size:12px;font-weight:600;display:flex;align-items:center;gap:5px}
.badge-green{background:rgba(16,185,129,0.1);border:1px solid rgba(16,185,129,0.3);color:var(--green)}
.badge-purple{background:rgba(124,58,237,0.1);border:1px solid rgba(124,58,237,0.3);color:#a78bfa}
.badge-pink{background:rgba(225,48,108,0.1);border:1px solid rgba(225,48,108,0.3);color:var(--pink)}
.content{padding:28px 32px}
.stats-row{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-bottom:28px}
.stat-card{background:var(--bg2);border:1px solid var(--border);border-radius:14px;padding:20px;position:relative;overflow:hidden}
.stat-card::before{content:'';position:absolute;top:0;right:0;width:80px;height:80px;border-radius:50%;filter:blur(30px);opacity:0.15}
.stat-card.purple::before{background:var(--purple)}
.stat-card.pink::before{background:var(--pink)}
.stat-card.cyan::before{background:var(--cyan)}
.stat-card.gold::before{background:var(--gold)}
.stat-num{font-size:32px;font-weight:900;line-height:1}
.stat-label{font-size:13px;color:var(--muted);margin-top:6px}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:20px}
.card{background:var(--bg2);border:1px solid var(--border);border-radius:16px;padding:22px}
.card-title{font-size:14px;font-weight:700;color:#a78bfa;margin-bottom:16px;display:flex;align-items:center;gap:8px}
.prod-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;max-height:380px;overflow-y:auto;padding-right:4px}
.prod-item{display:flex;align-items:center;gap:10px;padding:10px;border-radius:10px;border:1.5px solid var(--border);cursor:pointer;transition:all .2s;background:transparent}
.prod-item:hover{border-color:rgba(124,58,237,0.4);background:rgba(124,58,237,0.05)}
.prod-item.sel{border-color:var(--purple);background:rgba(124,58,237,0.12)}
.prod-img{width:42px;height:42px;border-radius:8px;object-fit:cover;flex-shrink:0;background:var(--bg3)}
.prod-name{font-size:12px;font-weight:600;line-height:1.3;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}
.prod-price{font-size:11px;color:var(--purple);margin-top:2px}
.chip-row{display:flex;gap:8px;flex-wrap:wrap}
.chip{padding:8px 16px;border-radius:50px;border:1.5px solid var(--border);cursor:pointer;font-size:13px;font-weight:500;transition:all .2s;background:transparent;color:var(--muted);font-family:'Tajawal',sans-serif}
.chip:hover{border-color:rgba(124,58,237,0.5);color:var(--text)}
.chip.on{border-color:var(--purple);background:rgba(124,58,237,0.15);color:#c4b5fd}
.btn{padding:12px 24px;border-radius:12px;border:none;font-family:'Tajawal',sans-serif;font-size:15px;font-weight:700;cursor:pointer;transition:all .25s;display:inline-flex;align-items:center;justify-content:center;gap:8px}
.btn-primary{background:linear-gradient(135deg,var(--purple),var(--pink));color:#fff}
.btn-primary:hover{transform:translateY(-2px);box-shadow:0 8px 25px rgba(124,58,237,0.4)}
.btn-primary:disabled{opacity:.5;cursor:not-allowed;transform:none}
.btn-ghost{background:rgba(255,255,255,0.05);border:1px solid var(--border);color:var(--text)}
.btn-ghost:hover{background:rgba(255,255,255,0.09)}
.btn-green{background:rgba(16,185,129,0.15);border:1px solid rgba(16,185,129,0.3);color:var(--green)}
.btn-green:hover{background:rgba(16,185,129,0.25)}
.btn-danger{background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.3);color:#f87171}
.input{background:rgba(255,255,255,0.05);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-family:'Tajawal',sans-serif;font-size:14px;width:100%;outline:none;transition:border .2s}
.input:focus{border-color:rgba(124,58,237,0.5)}
.content-block{background:var(--bg3);border:1px solid var(--border);border-radius:12px;padding:16px;margin-bottom:12px}
.block-label{font-size:12px;color:var(--muted);margin-bottom:8px;font-weight:600}
.block-text{font-size:15px;line-height:1.8;color:var(--text)}
.hashtag{display:inline-block;background:rgba(124,58,237,0.12);border:1px solid rgba(124,58,237,0.25);border-radius:50px;padding:3px 10px;font-size:12px;color:#c4b5fd;margin:3px}
.queue-item{background:var(--bg3);border:1px solid var(--border);border-radius:12px;padding:14px;margin-bottom:10px;display:flex;gap:12px;align-items:center}
.queue-img{width:48px;height:48px;border-radius:8px;object-fit:cover;flex-shrink:0}
.queue-info{flex:1;min-width:0}
.queue-title{font-size:13px;font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.queue-meta{font-size:11px;color:var(--muted);margin-top:4px;display:flex;gap:8px;align-items:center}
.status-badge{padding:2px 10px;border-radius:50px;font-size:11px;font-weight:600}
.status-pending{background:rgba(245,158,11,0.15);color:var(--gold)}
.status-sent{background:rgba(16,185,129,0.15);color:var(--green)}
.status-failed{background:rgba(239,68,68,0.15);color:#f87171}
.auto-toggle{display:flex;align-items:center;gap:12px;padding:16px;background:var(--bg3);border-radius:12px;border:1px solid var(--border)}
.toggle{position:relative;width:52px;height:28px;cursor:pointer}
.toggle input{opacity:0;width:0;height:0}
.slider{position:absolute;top:0;left:0;right:0;bottom:0;background:var(--muted);border-radius:50px;transition:.3s}
.slider:before{content:'';position:absolute;width:20px;height:20px;right:4px;bottom:4px;background:#fff;border-radius:50%;transition:.3s}
.toggle input:checked+.slider{background:var(--green)}
.toggle input:checked+.slider:before{transform:translateX(-24px)}
.pulse{animation:pulse 1.5s infinite}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.5}}
.spin{animation:spin 1s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
.slide-in{animation:slideIn .3s ease}
@keyframes slideIn{from{transform:translateY(16px);opacity:0}to{transform:translateY(0);opacity:1}}
.glow-purple{box-shadow:0 0 20px rgba(124,58,237,0.25)}
.divider{height:1px;background:var(--border);margin:20px 0}
.full-w{width:100%}
.copy-btn{padding:5px 12px;font-size:12px;border-radius:8px;background:rgba(255,255,255,0.06);border:1px solid var(--border);color:var(--muted);cursor:pointer;font-family:'Tajawal',sans-serif;transition:all .2s}
.copy-btn:hover{color:var(--text);background:rgba(255,255,255,0.1)}
.empty{text-align:center;padding:40px;color:var(--muted);opacity:.5}
.empty-icon{font-size:48px;margin-bottom:12px}
.section-title{font-size:18px;font-weight:800;margin-bottom:20px;display:flex;align-items:center;gap:10px}
.alert{padding:14px 18px;border-radius:12px;font-size:14px;margin-top:12px}
.alert-success{background:rgba(16,185,129,0.1);border:1px solid rgba(16,185,129,0.3);color:var(--green)}
.alert-error{background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.3);color:#f87171}
.alert-info{background:rgba(124,58,237,0.1);border:1px solid rgba(124,58,237,0.3);color:#a78bfa}
.row{display:flex;align-items:center;gap:12px}
.ml-auto{margin-right:auto}
@media(max-width:900px){.app{grid-template-columns:1fr}.sidebar{display:none}.stats-row{grid-template-columns:1fr 1fr}.grid2{grid-template-columns:1fr}}
`;

// ─── Main App ─────────────────────────────────────────────────────
export default function Dashboard() {
  const [tab, setTab] = useState<'generate'|'autopilot'|'queue'|'settings'>('generate');
  const [products, setProducts] = useState<Product[]>([]);
  const [loadingProducts, setLoadingProducts] = useState(true);
  const [selectedProduct, setSelectedProduct] = useState<string>('');
  const [platform, setPlatform] = useState('instagram');
  const [contentType, setContentType] = useState('post');
  const [tone, setTone] = useState('luxury');
  const [generating, setGenerating] = useState(false);
  const [generated, setGenerated] = useState<GeneratedContent | null>(null);
  const [queue, setQueue] = useState<QueuedPost[]>([]);
  const [stats, setStats] = useState<Stats>({ totalSent: 0, totalFailed: 0, lastRun: '' });
  const [autopilot, setAutopilot] = useState<AutoPilotSettings>({
    enabled: false, postsPerDay: 2, platforms: ['instagram'], preferredTimes: ['09:00', '20:00'],
    tones: ['luxury', 'educational'], contentTypes: ['post', 'story'], zapierWebhookUrl: '', rotateProducts: true,
  });
  const [scheduleTime, setScheduleTime] = useState('');
  const [zapierUrl, setZapierUrl] = useState('');
  const [publishStatus, setPublishStatus] = useState<string>('');
  const [publishAlert, setPublishAlert] = useState<{type:'success'|'error'|'info', msg:string}|null>(null);
  const [savingAutopilot, setSavingAutopilot] = useState(false);
  const [productSearch, setProductSearch] = useState('');
  const pollRef = useRef<NodeJS.Timeout>();

  // Load products
  const loadProducts = useCallback(async () => {
    setLoadingProducts(true);
    try {
      const res = await fetch('/api/products');
      const data = await res.json();
      if (data.products) setProducts(data.products);
    } catch { setProducts([]); }
    setLoadingProducts(false);
  }, []);

  // Load queue
  const loadQueue = useCallback(async () => {
    try {
      const res = await fetch('/api/queue');
      const data = await res.json();
      if (data.queue) setQueue(data.queue);
      if (data.stats) setStats(data.stats);
    } catch {}
  }, []);

  // Load autopilot settings
  const loadAutopilot = useCallback(async () => {
    try {
      const res = await fetch('/api/scheduler');
      const data = await res.json();
      if (data.settings) setAutopilot(data.settings);
    } catch {}
  }, []);

  useEffect(() => {
    loadProducts();
    loadQueue();
    loadAutopilot();
    // Poll queue every 30s
    pollRef.current = setInterval(() => { loadQueue(); }, 30000);
    return () => clearInterval(pollRef.current);
  }, []);

  // Generate content
  const handleGenerate = async () => {
    if (!selectedProduct) return;
    setGenerating(true);
    setGenerated(null);
    const product = products.find(p => p.id === selectedProduct);
    try {
      const res = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ product, platform, contentType, tone }),
      });
      const data = await res.json();
      if (data.content) setGenerated(data.content);
    } catch {}
    setGenerating(false);
  };

  // Add to queue
  const handleAddToQueue = async () => {
    if (!generated || !selectedProduct) return;
    const product = products.find(p => p.id === selectedProduct);
    if (!product) return;
    const scheduledFor = scheduleTime ? new Date(scheduleTime).toISOString() : new Date().toISOString();
    const webhookUrl = zapierUrl || autopilot.zapierWebhookUrl;
    await fetch('/api/queue', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        productId: product.id, productTitle: product.title, productImage: product.image,
        productPrice: `${product.price} ${product.currency}`,
        platform, contentType, tone,
        caption: generated.mainText, hashtags: generated.hashtags, hook: generated.hook,
        cta: generated.cta, bestTime: generated.bestTime, visualTip: generated.visualTip,
        scheduledFor, status: 'pending', zapierWebhookUrl: webhookUrl, autoMode: false,
      }),
    });
    await loadQueue();
    setPublishAlert({ type: 'success', msg: '✅ تمت إضافة المنشور للطابور' });
    setTimeout(() => setPublishAlert(null), 4000);
  };

  // Publish now via Zapier
  const handlePublishNow = async () => {
    if (!generated || !selectedProduct) return;
    const webhookUrl = zapierUrl || autopilot.zapierWebhookUrl;
    if (!webhookUrl) {
      setPublishAlert({ type: 'error', msg: '❌ أضف رابط Zapier Webhook في الإعدادات' });
      return;
    }
    setPublishStatus('sending');
    const product = products.find(p => p.id === selectedProduct);
    try {
      const res = await fetch('/api/publish', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          post: {
            productId: product?.id, productTitle: product?.title,
            productImage: product?.image, productPrice: `${product?.price} ${product?.currency}`,
            platform, contentType, tone,
            caption: generated.mainText, hashtags: generated.hashtags,
            hook: generated.hook, cta: generated.cta, scheduledFor: new Date().toISOString(),
          },
          webhookUrl,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setPublishAlert({ type: 'success', msg: `🚀 تم الإرسال لـ Zapier! سيُنشر على ${platform === 'both' ? 'Instagram و TikTok' : platform}` });
        await loadQueue();
      } else {
        setPublishAlert({ type: 'error', msg: `❌ خطأ: ${data.error}` });
      }
    } catch (e: any) {
      setPublishAlert({ type: 'error', msg: `❌ ${e.message}` });
    }
    setPublishStatus('');
    setTimeout(() => setPublishAlert(null), 6000);
  };

  // Save autopilot
  const saveAutopilot = async () => {
    setSavingAutopilot(true);
    await fetch('/api/scheduler', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(autopilot),
    });
    setSavingAutopilot(false);
    setPublishAlert({ type: 'success', msg: '✅ تم حفظ إعدادات الأوتوبايلوت' });
    setTimeout(() => setPublishAlert(null), 3000);
  };

  // Delete queue item
  const deletePost = async (id: string) => {
    await fetch('/api/queue', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) });
    setQueue(q => q.filter(p => p.id !== id));
  };

  const copy = (text: string) => navigator.clipboard.writeText(text);

  const filteredProducts = products.filter(p =>
    p.title.toLowerCase().includes(productSearch.toLowerCase()) || p.vendor?.toLowerCase().includes(productSearch.toLowerCase())
  );

  const pendingCount = queue.filter(q => q.status === 'pending').length;
  const sentCount = queue.filter(q => q.status === 'sent').length;

  return (
    <>
      <style>{css}</style>
      <div className="app">
        {/* ── SIDEBAR ── */}
        <aside className="sidebar">
          <div className="sidebar-logo">
            <div className="logo-text">SeoulGlow 🇰🇷</div>
            <div className="logo-sub">Auto Marketing Engine</div>
          </div>
          <div className="nav-section">
            <div className="nav-label">التسويق</div>
            {[
              { id: 'generate', icon: '✨', label: 'توليد محتوى' },
              { id: 'autopilot', icon: '🤖', label: 'أوتوبايلوت' },
              { id: 'queue', icon: '📋', label: `الطابور (${pendingCount})` },
              { id: 'settings', icon: '⚙️', label: 'الإعدادات' },
            ].map(n => (
              <button key={n.id} className={`nav-btn ${tab === n.id ? 'active' : ''}`} onClick={() => setTab(n.id as any)}>
                <span className="nav-icon">{n.icon}</span>
                {n.label}
                {n.id === 'autopilot' && (
                  <span className={`status-dot ${autopilot.enabled ? 'status-on' : 'status-off'}`} />
                )}
              </button>
            ))}
          </div>
          <div className="nav-section" style={{ marginTop: 'auto', borderTop: '1px solid rgba(255,255,255,0.06)', paddingTop: 16 }}>
            <div style={{ padding: '10px 12px', fontSize: 12, color: '#4b5563' }}>
              <div style={{ marginBottom: 6 }}>📊 إحصائيات</div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                <span>تم الإرسال</span><span style={{ color: '#10b981', fontWeight: 700 }}>{stats.totalSent}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                <span>في الطابور</span><span style={{ color: '#f59e0b', fontWeight: 700 }}>{pendingCount}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span>المنتجات</span><span style={{ color: '#a78bfa', fontWeight: 700 }}>{products.length}</span>
              </div>
            </div>
          </div>
        </aside>

        {/* ── MAIN ── */}
        <main className="main">
          {/* Topbar */}
          <div className="topbar">
            <div className="topbar-title">
              {tab === 'generate' && '✨ توليد محتوى'}
              {tab === 'autopilot' && '🤖 أوتوبايلوت'}
              {tab === 'queue' && '📋 الطابور'}
              {tab === 'settings' && '⚙️ الإعدادات'}
            </div>
            <div className="topbar-badges">
              <span className="badge badge-green">● Shopify</span>
              <span className="badge badge-purple">● Zapier</span>
              <span className={`badge ${autopilot.enabled ? 'badge-green' : 'badge-pink'}`}>
                {autopilot.enabled ? '● أوتوبايلوت شغال' : '○ أوتوبايلوت متوقف'}
              </span>
            </div>
          </div>

          <div className="content">
            {/* Stats */}
            <div className="stats-row">
              <div className="stat-card purple">
                <div className="stat-num" style={{ color: '#a78bfa' }}>{products.length}</div>
                <div className="stat-label">منتج في Shopify</div>
              </div>
              <div className="stat-card gold">
                <div className="stat-num" style={{ color: '#f59e0b' }}>{pendingCount}</div>
                <div className="stat-label">منشور جاهز</div>
              </div>
              <div className="stat-card cyan">
                <div className="stat-num" style={{ color: '#22d3ee' }}>{stats.totalSent}</div>
                <div className="stat-label">تم النشر</div>
              </div>
              <div className="stat-card pink">
                <div className="stat-num" style={{ color: '#e1306c' }}>{autopilot.postsPerDay}</div>
                <div className="stat-label">منشور يومياً</div>
              </div>
            </div>

            {publishAlert && (
              <div className={`alert alert-${publishAlert.type} slide-in`} style={{ marginBottom: 20 }}>
                {publishAlert.msg}
              </div>
            )}

            {/* ── GENERATE TAB ── */}
            {tab === 'generate' && (
              <div className="grid2">
                {/* Left: Controls */}
                <div>
                  <div className="card" style={{ marginBottom: 16 }}>
                    <div className="card-title">🛍️ اختر المنتج</div>
                    <input className="input" placeholder="🔍 بحث في المنتجات..." style={{ marginBottom: 12 }} value={productSearch} onChange={e => setProductSearch(e.target.value)} />
                    {loadingProducts ? (
                      <div style={{ textAlign: 'center', padding: 20, color: '#6b7280' }}>
                        <div className="spin" style={{ width: 24, height: 24, border: '2px solid rgba(124,58,237,0.3)', borderTopColor: '#7c3aed', borderRadius: '50%', margin: '0 auto' }} />
                      </div>
                    ) : (
                      <div className="prod-grid">
                        {filteredProducts.map(p => (
                          <div key={p.id} className={`prod-item ${selectedProduct === p.id ? 'sel' : ''}`} onClick={() => setSelectedProduct(p.id)}>
                            <img src={p.image} alt={p.title} className="prod-img" onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                            <div>
                              <div className="prod-name">{p.title}</div>
                              <div className="prod-price">{p.price} {p.currency}</div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="card" style={{ marginBottom: 16 }}>
                    <div className="card-title">🎯 إعدادات المحتوى</div>
                    <div style={{ marginBottom: 14 }}>
                      <div style={{ fontSize: 12, color: '#6b7280', marginBottom: 8 }}>المنصة</div>
                      <div className="chip-row">
                        {PLATFORM_OPTIONS.map(p => <button key={p.id} className={`chip ${platform === p.id ? 'on' : ''}`} onClick={() => setPlatform(p.id)}>{p.icon} {p.label}</button>)}
                      </div>
                    </div>
                    <div style={{ marginBottom: 14 }}>
                      <div style={{ fontSize: 12, color: '#6b7280', marginBottom: 8 }}>نوع المحتوى</div>
                      <div className="chip-row">
                        {TYPE_OPTIONS.map(t => <button key={t.id} className={`chip ${contentType === t.id ? 'on' : ''}`} onClick={() => setContentType(t.id)}>{t.label}</button>)}
                      </div>
                    </div>
                    <div>
                      <div style={{ fontSize: 12, color: '#6b7280', marginBottom: 8 }}>الأسلوب</div>
                      <div className="chip-row">
                        {TONE_OPTIONS.map(t => <button key={t.id} className={`chip ${tone === t.id ? 'on' : ''}`} onClick={() => setTone(t.id)}>{t.label}</button>)}
                      </div>
                    </div>
                  </div>

                  <button className="btn btn-primary full-w" onClick={handleGenerate} disabled={!selectedProduct || generating} style={{ fontSize: 17, padding: '15px' }}>
                    {generating ? <><span className="spin" style={{ width: 18, height: 18, border: '2px solid rgba(255,255,255,0.3)', borderTopColor: '#fff', borderRadius: '50%', display: 'inline-block' }} /> جاري التوليد...</> : '✨ ولّد المحتوى'}
                  </button>
                </div>

                {/* Right: Output */}
                <div>
                  {!generated && !generating && (
                    <div className="card" style={{ height: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: 400 }}>
                      <div className="empty">
                        <div className="empty-icon">🤖</div>
                        <div>اختر منتج وابدأ التوليد</div>
                      </div>
                    </div>
                  )}
                  {generating && (
                    <div className="card" style={{ height: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: 400, gap: 20 }}>
                      <div className="spin" style={{ width: 52, height: 52, border: '3px solid rgba(124,58,237,0.2)', borderTopColor: '#7c3aed', borderRadius: '50%' }} />
                      <div style={{ color: '#a78bfa', fontSize: 16 }}>الذكاء الاصطناعي يكتب محتواك...</div>
                    </div>
                  )}
                  {generated && !generating && (
                    <div className="slide-in">
                      {/* Hook */}
                      <div className="content-block glow-purple" style={{ borderColor: 'rgba(124,58,237,0.3)' }}>
                        <div className="row"><div className="block-label">⚡ الهوك</div><button className="copy-btn" onClick={() => copy(generated.hook)}>نسخ</button></div>
                        <div className="block-text" style={{ fontWeight: 700, fontSize: 17, color: '#c4b5fd' }}>{generated.hook}</div>
                      </div>

                      {/* Main Text */}
                      <div className="content-block">
                        <div className="row"><div className="block-label">📝 النص الرئيسي</div><button className="copy-btn" onClick={() => copy(generated.mainText)}>نسخ</button></div>
                        <div className="block-text" style={{ whiteSpace: 'pre-line' }}>{generated.mainText}</div>
                      </div>

                      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                        <div className="content-block">
                          <div className="block-label" style={{ color: '#f59e0b' }}>🎯 CTA</div>
                          <div className="block-text" style={{ fontSize: 13 }}>{generated.cta}</div>
                        </div>
                        <div className="content-block">
                          <div className="block-label" style={{ color: '#10b981' }}>⏰ أفضل وقت</div>
                          <div className="block-text" style={{ fontSize: 13 }}>{generated.bestTime}</div>
                        </div>
                      </div>

                      <div className="content-block">
                        <div className="block-label" style={{ color: '#22d3ee' }}>📸 نصيحة الفيزوال</div>
                        <div className="block-text" style={{ fontSize: 13 }}>{generated.visualTip}</div>
                      </div>

                      <div className="content-block">
                        <div className="row"><div className="block-label"># الهاشتاقات</div><button className="copy-btn" onClick={() => copy(generated.hashtags.join(' '))}>نسخ الكل</button></div>
                        <div>{generated.hashtags.map((h, i) => <span key={i} className="hashtag">{h}</span>)}</div>
                      </div>

                      {/* Publish controls */}
                      <div className="card" style={{ marginTop: 4, borderColor: 'rgba(124,58,237,0.2)' }}>
                        <div style={{ fontSize: 13, color: '#6b7280', marginBottom: 12 }}>⚡ نشر أو جدولة</div>
                        <input type="text" className="input" placeholder="🔗 رابط Zapier Webhook (أو ضبطه في الإعدادات)" value={zapierUrl} onChange={e => setZapierUrl(e.target.value)} style={{ marginBottom: 10 }} />
                        <input type="datetime-local" className="input" value={scheduleTime} onChange={e => setScheduleTime(e.target.value)} style={{ marginBottom: 12 }} />
                        <div style={{ display: 'flex', gap: 10 }}>
                          <button className="btn btn-primary" style={{ flex: 1 }} onClick={handlePublishNow} disabled={publishStatus === 'sending'}>
                            {publishStatus === 'sending' ? <span className="pulse">⏳ إرسال...</span> : '🚀 نشر الآن عبر Zapier'}
                          </button>
                          <button className="btn btn-ghost" style={{ flex: 1 }} onClick={handleAddToQueue}>📋 أضف للطابور</button>
                        </div>
                        <button className="btn btn-ghost full-w" style={{ marginTop: 10 }} onClick={() => copy(generated.fullCaption)}>📋 نسخ المحتوى كامل</button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* ── AUTOPILOT TAB ── */}
            {tab === 'autopilot' && (
              <div>
                <div className="card" style={{ marginBottom: 20, borderColor: autopilot.enabled ? 'rgba(16,185,129,0.3)' : 'var(--border)' }}>
                  <div className="auto-toggle">
                    <div>
                      <div style={{ fontWeight: 700, fontSize: 16 }}>🤖 الأوتوبايلوت</div>
                      <div style={{ fontSize: 12, color: '#6b7280', marginTop: 4 }}>يولد وينشر أوتوماتيك على مدار اليوم</div>
                    </div>
                    <label className="toggle" style={{ marginRight: 'auto' }}>
                      <input type="checkbox" checked={autopilot.enabled} onChange={e => setAutopilot(a => ({ ...a, enabled: e.target.checked }))} />
                      <span className="slider" />
                    </label>
                  </div>
                </div>

                <div className="grid2">
                  <div className="card">
                    <div className="card-title">⚙️ إعدادات النشر</div>
                    <div style={{ marginBottom: 16 }}>
                      <div style={{ fontSize: 12, color: '#6b7280', marginBottom: 8 }}>عدد المنشورات يومياً</div>
                      <div className="chip-row">
                        {[1,2,3,4].map(n => <button key={n} className={`chip ${autopilot.postsPerDay === n ? 'on' : ''}`} onClick={() => setAutopilot(a => ({ ...a, postsPerDay: n }))}>{n} منشور</button>)}
                      </div>
                    </div>
                    <div style={{ marginBottom: 16 }}>
                      <div style={{ fontSize: 12, color: '#6b7280', marginBottom: 8 }}>المنصات</div>
                      <div className="chip-row">
                        {['instagram','tiktok'].map(p => (
                          <button key={p} className={`chip ${autopilot.platforms.includes(p) ? 'on' : ''}`} onClick={() => setAutopilot(a => ({
                            ...a, platforms: a.platforms.includes(p) ? a.platforms.filter(x=>x!==p) : [...a.platforms,p]
                          }))}>
                            {p === 'instagram' ? '📸 Instagram' : '🎵 TikTok'}
                          </button>
                        ))}
                      </div>
                    </div>
                    <div style={{ marginBottom: 16 }}>
                      <div style={{ fontSize: 12, color: '#6b7280', marginBottom: 8 }}>أسلوب المحتوى</div>
                      <div className="chip-row">
                        {TONE_OPTIONS.map(t => (
                          <button key={t.id} className={`chip ${autopilot.tones.includes(t.id) ? 'on' : ''}`} onClick={() => setAutopilot(a => ({
                            ...a, tones: a.tones.includes(t.id) ? a.tones.filter(x=>x!==t.id) : [...a.tones,t.id]
                          }))}>
                            {t.label}
                          </button>
                        ))}
                      </div>
                    </div>
                    <div>
                      <div style={{ fontSize: 12, color: '#6b7280', marginBottom: 8 }}>نوع المحتوى</div>
                      <div className="chip-row">
                        {TYPE_OPTIONS.map(t => (
                          <button key={t.id} className={`chip ${autopilot.contentTypes.includes(t.id) ? 'on' : ''}`} onClick={() => setAutopilot(a => ({
                            ...a, contentTypes: a.contentTypes.includes(t.id) ? a.contentTypes.filter(x=>x!==t.id) : [...a.contentTypes,t.id]
                          }))}>
                            {t.label}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="card">
                    <div className="card-title">⏰ أوقات النشر</div>
                    <div style={{ marginBottom: 16 }}>
                      <div style={{ fontSize: 12, color: '#6b7280', marginBottom: 10 }}>الأوقات المفضلة (اسحب لتغيير)</div>
                      {autopilot.preferredTimes.map((time, i) => (
                        <div key={i} style={{ display: 'flex', gap: 8, marginBottom: 8, alignItems: 'center' }}>
                          <input type="time" className="input" value={time} onChange={e => {
                            const times = [...autopilot.preferredTimes];
                            times[i] = e.target.value;
                            setAutopilot(a => ({ ...a, preferredTimes: times }));
                          }} style={{ flex: 1 }} />
                          <button className="btn btn-danger" style={{ padding: '8px 14px', fontSize: 13 }} onClick={() => setAutopilot(a => ({ ...a, preferredTimes: a.preferredTimes.filter((_,j)=>j!==i) }))}>✕</button>
                        </div>
                      ))}
                      <button className="btn btn-ghost" style={{ padding: '8px 16px', fontSize: 13 }} onClick={() => setAutopilot(a => ({ ...a, preferredTimes: [...a.preferredTimes, '12:00'] }))}>+ وقت جديد</button>
                    </div>
                    <div className="divider" />
                    <div>
                      <div style={{ fontSize: 12, color: '#6b7280', marginBottom: 8 }}>🔄 تدوير المنتجات أوتوماتيك</div>
                      <label className="toggle">
                        <input type="checkbox" checked={autopilot.rotateProducts} onChange={e => setAutopilot(a => ({ ...a, rotateProducts: e.target.checked }))} />
                        <span className="slider" />
                      </label>
                    </div>
                    <div className="divider" />
                    <div>
                      <div style={{ fontSize: 12, color: '#6b7280', marginBottom: 8 }}>🔗 رابط Zapier Webhook</div>
                      <input className="input" placeholder="https://hooks.zapier.com/hooks/catch/..." value={autopilot.zapierWebhookUrl} onChange={e => setAutopilot(a => ({ ...a, zapierWebhookUrl: e.target.value }))} />
                    </div>
                    <div style={{ marginTop: 16 }}>
                      <button className="btn btn-primary full-w" onClick={saveAutopilot} disabled={savingAutopilot}>
                        {savingAutopilot ? <span className="pulse">حفظ...</span> : '💾 حفظ الإعدادات'}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Cron info */}
                <div className="card" style={{ marginTop: 20, borderColor: 'rgba(124,58,237,0.2)' }}>
                  <div className="card-title">📡 جدول التشغيل الأوتوماتيكي (Vercel Cron)</div>
                  <div style={{ fontSize: 13, color: '#6b7280', lineHeight: 2 }}>
                    يتشغل النظام أوتوماتيكياً في: <strong style={{ color: '#a78bfa' }}>6ص، 9ص، 12م، 3م، 6م، 9م</strong> كل يوم<br />
                    يتحقق من الطابور وينشر المنشورات المجدولة ويولد محتوى جديد إذا لزم.<br />
                    <span style={{ color: '#10b981' }}>✅ مربوط بـ Vercel Cron Jobs — يشتغل لوحده 24/7</span>
                  </div>
                </div>
              </div>
            )}

            {/* ── QUEUE TAB ── */}
            {tab === 'queue' && (
              <div>
                <div className="row" style={{ marginBottom: 20 }}>
                  <div className="section-title">📋 طابور المنشورات</div>
                  <button className="btn btn-ghost" style={{ marginRight: 'auto', fontSize: 13 }} onClick={loadQueue}>🔄 تحديث</button>
                </div>
                {queue.length === 0 ? (
                  <div className="empty"><div className="empty-icon">📭</div><div>الطابور فاضي — ولّد محتوى وأضفه!</div></div>
                ) : (
                  queue.map(post => (
                    <div key={post.id} className="queue-item slide-in">
                      <img src={post.productImage} alt="" className="queue-img" onError={e => { (e.target as HTMLImageElement).style.display='none'; }} />
                      <div className="queue-info">
                        <div className="queue-title">{post.productTitle}</div>
                        <div className="queue-meta">
                          <span className={`status-badge status-${post.status}`}>{post.status === 'pending' ? '⏳ جاهز' : post.status === 'sent' ? '✅ تم النشر' : '❌ فشل'}</span>
                          <span>{post.platform}</span>
                          <span>{post.contentType}</span>
                          {post.autoMode && <span style={{ color: '#7c3aed' }}>🤖 أوتو</span>}
                        </div>
                        <div style={{ fontSize: 11, color: '#4b5563', marginTop: 4 }}>
                          📅 {new Date(post.scheduledFor).toLocaleString('ar-AE')}
                        </div>
                      </div>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                        <button className="btn btn-danger" style={{ padding: '6px 14px', fontSize: 12 }} onClick={() => deletePost(post.id)}>حذف</button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* ── SETTINGS TAB ── */}
            {tab === 'settings' && (
              <div className="grid2">
                <div className="card">
                  <div className="card-title">🔗 Zapier Webhook</div>
                  <div style={{ fontSize: 13, color: '#6b7280', marginBottom: 12, lineHeight: 1.8 }}>
                    1. روح Zapier وسوّ Zap جديد<br />
                    2. Trigger: <strong>Webhooks by Zapier</strong> → Catch Hook<br />
                    3. Action: <strong>Instagram for Business</strong> → Create Photo Post<br />
                    4. انسخ رابط الـ Webhook وحطه هنا
                  </div>
                  <input className="input" placeholder="https://hooks.zapier.com/hooks/catch/XXXXX/YYYYY/" value={autopilot.zapierWebhookUrl} onChange={e => setAutopilot(a => ({ ...a, zapierWebhookUrl: e.target.value }))} style={{ marginBottom: 12 }} />
                  <button className="btn btn-primary" onClick={saveAutopilot}>💾 حفظ</button>
                </div>

                <div className="card">
                  <div className="card-title">📦 Shopify</div>
                  <div style={{ fontSize: 13, color: '#6b7280', lineHeight: 2 }}>
                    المتجر: <strong style={{ color: '#a78bfa' }}>SeoulGlowUAE</strong><br />
                    عدد المنتجات: <strong style={{ color: '#10b981' }}>{products.length} منتج</strong><br />
                    الحالة: <strong style={{ color: '#10b981' }}>✅ متصل</strong>
                  </div>
                  <div className="divider" />
                  <button className="btn btn-ghost" onClick={loadProducts}>🔄 تحديث المنتجات</button>
                </div>

                <div className="card" style={{ gridColumn: '1/-1' }}>
                  <div className="card-title">📖 دليل ربط Zapier بـ Instagram و TikTok</div>
                  <div style={{ fontSize: 13, color: '#9ca3af', lineHeight: 2.2 }}>
                    <strong style={{ color: '#c4b5fd' }}>Instagram:</strong><br />
                    ١. Zapier → New Zap → Trigger: Webhooks → Catch Hook<br />
                    ٢. Action: Instagram for Business → Create Photo Post<br />
                    ٣. Map الحقول: Image URL = product_image_url | Caption = full_caption<br />
                    ٤. فعّل الـ Zap وانسخ رابط الـ Webhook<br />
                    <br />
                    <strong style={{ color: '#69c9d0' }}>TikTok:</strong><br />
                    ١. نفس الخطوات مع Action: TikTok for Business → Upload Video<br />
                    ٢. تحتاج فيديو للتيك توك — استخدم Higgsfield لتوليد فيديو أول<br />
                    <br />
                    <strong style={{ color: '#10b981' }}>Buffer / Later (الأسهل):</strong><br />
                    ١. Action: Buffer → Create Update<br />
                    ٢. يدعم Instagram وTikTok من نفس الـ Zap
                  </div>
                </div>
              </div>
            )}
          </div>
        </main>
      </div>
    </>
  );
}
